from flask import Flask, request, render_template
import pickle
import numpy as np

app = Flask('him')

# Load the trained model
with open("model.pkl", "rb") as f:
    model = pickle.load(f)

@app.route('/')
def home():
    return render_template("index.html")

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        features = [
            float(request.form['pregnancies']),
            float(request.form['glucose']),
            float(request.form['blood_pressure']),
            float(request.form['skin_thickness']),
            float(request.form['insulin']),
            float(request.form['bmi']),
            float(request.form['diabetes_pedigree']),
            float(request.form['age'])
        ]
        prediction = model.predict([features])[0]
        result = "Diabetic" if prediction == 1 else "Not Diabetic"
        return render_template("index.html", prediction_text=f"The prediction is: {result}")

if __name__ == "__main__":
    app.run(debug=True)
